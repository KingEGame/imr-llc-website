import { useReveal } from '../hooks/useReveal'
import './Work.css'

const projects = [
  {
    kind: 'AI Agents · Research',
    title: 'Autonomous Research Desk',
    body: 'Agents that monitor hundreds of sources, summarize findings and flag signals for the research team in real time.',
    tech: ['Python', 'LLM Agents', 'Postgres'],
  },
  {
    kind: 'Software · Operations',
    title: 'Ops Control Platform',
    body: 'A custom platform unifying reconciliation, reporting and exception handling into a single operational console.',
    tech: ['TypeScript', 'React', 'Node'],
  },
  {
    kind: 'Automation · Finance',
    title: 'Close Automation',
    body: 'A pipeline that automates the monthly close — from a four-day manual process down to under four hours.',
    tech: ['Airflow', 'dbt', 'Python'],
  },
  {
    kind: 'Orchestration',
    title: 'Agent Orchestration Layer',
    body: 'Coordinates dozens of agents and services into observable, resilient end-to-end workflows that scale.',
    tech: ['Temporal', 'Go', 'Kubernetes'],
  },
]

export default function Work() {
  const gridRef = useReveal<HTMLDivElement>({ stagger: 90 })
  return (
    <section className="work section" id="work">
      <div className="shell">
        <span className="eyebrow">04 · Selected work</span>
        <h2 className="section-title">Systems we&rsquo;ve shipped.</h2>
        <p className="section-lead">
          A sample of the platforms, agents and automations now running in
          production for our clients.
        </p>
        <div className="work-grid" ref={gridRef}>
          {projects.map((p) => (
            <article key={p.title} className="work-card" data-reveal>
              <span className="work-kind">{p.kind}</span>
              <h3 className="work-title">{p.title}</h3>
              <p className="work-body">{p.body}</p>
              <div className="work-tech">
                {p.tech.map((t) => (
                  <span key={t} className="chip">
                    {t}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
